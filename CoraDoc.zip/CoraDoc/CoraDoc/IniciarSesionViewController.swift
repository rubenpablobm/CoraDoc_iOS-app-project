//
//  IniciarSesionViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 08/09/22.
//

import UIKit
import FirebaseAuth

class IniciarSesionViewController: UIViewController {
    
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfContrasena: UITextField!
    @IBOutlet weak var lbError: UILabel!
    @IBOutlet weak var btnIniciarSesion: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpElements()
    }
    
    func setUpElements() {
        // esconde label de Error
        lbError.alpha = 0
    }
    
//    MARK: - Funciones de botones
    @IBAction func btnIniciarSesion(_ sender: UIButton) {
        // Valida los datos
        let error = validarCampos()
        
        if error != nil {
            // Hubo un error
            mostrarError(error!)
        }
        else {
            // Crea versiones limpias de los datos
            let email = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let contrasena = tfContrasena.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            // Ingresa el usuario
            Auth.auth().signIn(withEmail: email, password: contrasena) { (result, error) in
                if error != nil {
                    // No se pudo ingresar
                    if error!.localizedDescription ==
                        "The password is invalid or the user does not have a password." {
                        // la contraseña es inválida
                        self.mostrarError("La contraseña es incorrecta.")
                    }
                    else if error!.localizedDescription ==
                        "There is no user record corresponding to this identifier. The user may have been deleted." {
                        // el correo no está registrado
                        self.mostrarError("No existe una cuenta con ese correo electrónico.")
                    }
                    else {
                        self.mostrarError(error!.localizedDescription)
                    }
                }
                else {
                    // Se logró ingresar
                    self.performSegue(withIdentifier: "iniciarSesionSegue", sender: Any?.self)
                }
            }
        }
    }
    
    @IBAction func btnCancelar(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func quitarTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
//    MARK: - Funciones de validación
    
    // Valida que los datos son correctos, en ese caso regresa nil. De lo contrario regresa el mensaje de error.
    func validarCampos() -> String? {
        
        // Verifica que todos los campos tengan datos
        if tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfContrasena.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "No deje ningún campo vacío"
        }
        
        //Verifica que el formato del correo sea correcto
        let emailLimpio = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if !correoEsValido(emailLimpio) {
            tfEmail.text = ""
            return "El correo electrónico no es válido"
        }
        
        return nil
    }
    
    // Valida que el correo sea válido
    func correoEsValido(_ email: String) -> Bool {
        let mailPrueba = NSPredicate(format: "SELF MATCHES %@",
                                     "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}")
        return mailPrueba.evaluate(with: email)
    }
    
    func mostrarError(_ mensaje: String) {
        lbError.text = mensaje
        lbError.alpha = 1
    }
    
    
    // MARK: - Navigation

    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
     */

}
