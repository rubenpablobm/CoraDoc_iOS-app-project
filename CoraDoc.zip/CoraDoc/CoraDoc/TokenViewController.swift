//
//  TokenViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 21/09/22.
//

import UIKit
import Firebase

class TokenViewController: UIViewController {

    @IBOutlet weak var lbToken: UILabel!
    @IBOutlet weak var lbMensaje: UILabel!
    
    var idPaciente = Auth.auth().currentUser?.uid
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupElements()
    }
    
    @IBAction func copiarToken(_ sender: UIButton) {
        // Copia el texto de lbToken
        UIPasteboard.general.string = lbToken.text
        lbMensaje.alpha = 1
    }
    
    func setupElements() {
        lbMensaje.alpha = 0
        lbMensaje.textColor = .systemBlue
        lbToken.text = idPaciente
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
