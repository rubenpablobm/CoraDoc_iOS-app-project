//
//  CuestionarioViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 20/09/22.
//

import UIKit
import Firebase

class CuestionarioViewController: UIViewController {
    
    @IBOutlet weak var indicadorMedicamento: UITextField!
    @IBOutlet weak var sliderMedicamento: UISlider!
    @IBOutlet weak var indicadorBienestar: UITextField!
    @IBOutlet weak var sliderBienestar: UISlider!
    @IBOutlet weak var indicadorDormir: UITextField!
    @IBOutlet weak var sliderDormir: UISlider!
    @IBOutlet weak var indicadorEjercicio: UITextField!
    @IBOutlet weak var sliderEjercicio: UISlider!
    @IBOutlet weak var tfSintomas: UITextField!
    @IBOutlet weak var lbMensaje: UILabel!
    @IBOutlet weak var swDolorPecho: UISwitch!
    @IBOutlet weak var swDolorCuello: UISwitch!
    @IBOutlet weak var swHormigueo: UISwitch!
    @IBOutlet weak var swIndigestion: UISwitch!
    @IBOutlet weak var swNauseas: UISwitch!
    @IBOutlet weak var swVomito: UISwitch!
    @IBOutlet weak var swFatiga: UISwitch!
    @IBOutlet weak var swHinchazon: UISwitch!
    @IBOutlet weak var swDifRespirar: UISwitch!
    
    var fecha = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Cuestionario"
        
        setupElements()
    }
    
//    MARK: - Acciones de botón
    @IBAction func enviarRespuestas(_ sender: UIButton) {
        
        view.endEditing(true)
        
        let idPaciente = Auth.auth().currentUser?.uid
        let regularidadMed = indicadorMedicamento.text
        let bienestarGral = sliderBienestar.value
        let calidadSueno = sliderDormir.value
        let actividadFisica = sliderEjercicio.value
        let dolorPecho = checarSwitch(swDolorPecho)
        let dolorCuello = checarSwitch(swDolorCuello)
        let hormigueo = checarSwitch(swHormigueo)
        let indigestion = checarSwitch(swIndigestion)
        let nauseas = checarSwitch(swNauseas)
        let vomito = checarSwitch(swVomito)
        let fatiga = checarSwitch(swFatiga)
        let hinchazon = checarSwitch(swHinchazon)
        let difRespirar = checarSwitch(swDifRespirar)
        let otros = tfSintomas.text
        let fecha = formatoFecha(Date())
        let hora = formatoHora(Date())
        let idForm = fecha + "-" + (idPaciente ?? "x")
        
        let db = Firestore.firestore()
        
        let formulario = db.collection("formularios").document(idForm)
        
        formulario.setData(["idForm":idForm, "idPaciente":idPaciente ?? "x",
                            "regularidadMed":regularidadMed!, "bienestarGral":bienestarGral,
                            "calidadSueno":calidadSueno, "actividadFisica":actividadFisica,
                            "dolorPecho":dolorPecho, "dolorCuello":dolorCuello,
                            "hormigueo":hormigueo, "indigestion":indigestion,
                            "nauseas":nauseas, "vomito":vomito, "fatiga":fatiga,
                            "hinchazon":hinchazon, "difRespirar":difRespirar,
                            "otros":otros ?? "", "fecha":fecha, "hora":hora
                           ]) { (error) in
            if error != nil {
                // mostrar mensaje de error
                self.lbMensaje.text = "Error con el sistema, intente más tarde."
                self.lbMensaje.textColor = .systemRed
                self.lbMensaje.alpha = 1
            }
        }
        
        lbMensaje.text = "Las respuestas se enviaron exitosamente!"
        lbMensaje.textColor = .systemBlue
        lbMensaje.alpha = 1
        resetCampos()
    }
    
    @IBAction func btnTerminar(_ sender: UIButton) {
        // regresa a home
        self.navigationController?.popViewController(animated: true)
    }
    
    
//    MARK: - Acciones de sliders
    
    @IBAction func sliderMedicamento(_ sender: UISlider) {
        let indicador = Int(sliderMedicamento.value)
        
        if indicador < 1 {
            indicadorMedicamento.text = "Nunca"
        }
        else if indicador >= 1 && indicador < 2 {
            indicadorMedicamento.text = "Casi nunca"
        }
        else if indicador >= 2 && indicador < 3 {
            indicadorMedicamento.text = "Casi siempre"
        }
        else {
            indicadorMedicamento.text = "Siempre"
        }
    }
    
    @IBAction func sliderBienestar(_ sender: UISlider) {
        let indicador = Int(sliderBienestar.value)
        
        indicadorBienestar.text = String(indicador)
    }
    
    @IBAction func sliderDormir(_ sender: UISlider) {
        let indicador = Int(sliderDormir.value)
        
        indicadorDormir.text = String(indicador)
    }
    
    
    @IBAction func sliderEjercicio(_ sender: UISlider) {
        let indicador = Int(sliderEjercicio.value)
        
        indicadorEjercicio.text = String(indicador)
    }

//    MARK: - Funciones auxiliares
    
    func setupElements() {
        lbMensaje.alpha = 0
    }
    
    func formatoFecha(_ fecha: Date) -> String {
        let formato = DateFormatter()
        formato.dateFormat = "dd-MM-yyyy"
        return formato.string(from: fecha)
    }
    
    func formatoHora(_ hora: Date) -> String {
        let formato = DateFormatter()
        formato.dateFormat = "HH:mm:ss"
        return formato.string(from: hora)
    }
    
    func checarSwitch(_ sw: UISwitch) -> Bool {
        if sw.isOn {
            return true
        } else {
            return false
        }
    }
    
    func resetCampos() {
        indicadorMedicamento.text = "Casi nunca"
        sliderMedicamento.value = 1
        indicadorBienestar.text = "1"
        sliderBienestar.value = 1
        indicadorDormir.text = "1"
        sliderDormir.value = 1
        indicadorEjercicio.text = "1"
        sliderEjercicio.value = 1
        swDolorPecho.isOn = false
        swDolorCuello.isOn = false
        swHormigueo.isOn = false
        swIndigestion.isOn = false
        swNauseas.isOn = false
        swVomito.isOn = false
        swFatiga.isOn = false
        swHinchazon.isOn = false
        swDifRespirar.isOn = false
        tfSintomas.text = ""
    }
    
    @IBAction func quitarTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
