//
//  ViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 06/09/22.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        verificarSesion()
    }
    
    // Checa si el paciente tiene sesión iniciada
    func verificarSesion() {
     
        Auth.auth().addStateDidChangeListener { auth, user in
            if user != nil {
                // Si la sesión del usuario está activa se envía a Inicio
                self.performSegue(withIdentifier: "sesionActiva", sender: Any?.self)
            }
        }
    }
}

