//
//  HistorialViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 11/10/22.
//

import UIKit
import Firebase
import FirebaseFirestoreSwift
import Charts

class HistorialViewController: UIViewController, ChartViewDelegate {
    
    let db = Firestore.firestore()
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scPeriodo: UISegmentedControl!
    @IBOutlet weak var scVariable: UISegmentedControl!
    @IBOutlet weak var chartContainer: UIView!
    @IBOutlet weak var chartView: LineChartView!
    @IBOutlet weak var lbMensaje: UILabel!
    
    var idPaciente = Auth.auth().currentUser?.uid
    var registros = [Registro]()
//    var registros = Array<Registro>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Mi historial"
        
        // TRANSPARENCIA LBMENSAJE
        lbMensaje.alpha = 0
        
        // carga todos los registros del paciente
//        getData()
//        getRegistros()
//        cargarRegistros()
        
        
        // carga la gráfica de presión sistólica (TEMP)
        cargarChartSistolica()
        
        
        // SEGMENTED CONTROLLERS
    }
    
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        print(entry)
    }
    
    func iniciarChart() {
        
    }
    
    
    func ajustarChartSemanas() {
        
    }
    
    func ajustarChartDias() {
        // ESTILO DE LA GRÁFICA
        chartView.xAxis.setLabelCount(5, force: false)  // establece 5 etiquetas para el eje X
    }
    
    func cargarChartAmbas() {
        
    }
    
    func cargarChartSistolica() {
        // ESTILO GENERAL
        chartContainer.layer.cornerRadius = 20          // redondea las esquinas
        chartView.highlightPerDragEnabled = false       // desabilita la selección de puntos arrastrando el dedo
        chartView.rightAxis.enabled = false             // desabilita las etiquetas del borde derecho
        chartView.xAxis.labelPosition = .bottom         // posiciona las etiquetas del eje X en el borde inferior
        
        // ESTILO PARA PRES SISTÓLICA
        chartView.leftAxis.axisMinimum = Double(70)    // establece el rango de valores visibles para el eje Y
        chartView.leftAxis.axisMaximum = Double(200)
        let sisAlto = ChartLimitLine(limit: 140.0, label: "Presión alta")
        sisAlto.lineColor = .systemRed
        sisAlto.labelPosition = .leftTop
        let sisElev = ChartLimitLine(limit: 130.0)
        sisElev.lineColor = .systemYellow
        let sisNorm = ChartLimitLine(limit:120.0, label: "Presión normal")
        sisNorm.lineColor = .systemGreen
        sisNorm.labelPosition = .leftBottom
        chartView.leftAxis.addLimitLine(sisAlto)
        chartView.leftAxis.addLimitLine(sisElev)
        chartView.leftAxis.addLimitLine(sisNorm)
        
        // MOVIMIENTO PERMITIDO GENERAL
        chartView.setScaleEnabled(false)                // evita que se pueda modiciar la escala de la gráfica
        chartView.scaleYEnabled = true                  // permite que se pueda modificar la escala del eje Y
        chartView.scaleXEnabled = false                 // evita que se pueda modificar la escala del eje X
        
        chartView.dragXEnabled = true                   // permite que se pueda arrastrar la vista
        chartView.xAxis.setLabelCount(7, force: false)  // establece 7 etiquetas para el eje X, para los días de la semana
        
        // se declara el arreglo con los datos que serán graficados
        var puntos = [ChartDataEntry]()
        
        // se agregan valores al arreglo
        puntos.append(ChartDataEntry(x:Double(1), y:Double(120)))
        puntos.append(ChartDataEntry(x:Double(2), y:Double(130)))
        puntos.append(ChartDataEntry(x:Double(3), y:Double(125)))
        puntos.append(ChartDataEntry(x:Double(4), y:Double(140)))
        puntos.append(ChartDataEntry(x:Double(5), y:Double(145)))
        puntos.append(ChartDataEntry(x:Double(6), y:Double(125)))
        puntos.append(ChartDataEntry(x:Double(7), y:Double(130)))
        puntos.append(ChartDataEntry(x:Double(8), y:Double(117)))
        puntos.append(ChartDataEntry(x:Double(9), y:Double(123)))
        puntos.append(ChartDataEntry(x:Double(10), y:Double(136)))
        puntos.append(ChartDataEntry(x:Double(11), y:Double(130)))
        puntos.append(ChartDataEntry(x:Double(12), y:Double(145)))
        puntos.append(ChartDataEntry(x:Double(13), y:Double(126)))
        puntos.append(ChartDataEntry(x:Double(14), y:Double(133)))
        puntos.append(ChartDataEntry(x:Double(15), y:Double(120)))
        puntos.append(ChartDataEntry(x:Double(16), y:Double(137)))
        puntos.append(ChartDataEntry(x:Double(17), y:Double(126)))
        puntos.append(ChartDataEntry(x:Double(18), y:Double(117)))
        puntos.append(ChartDataEntry(x:Double(19), y:Double(125)))
        puntos.append(ChartDataEntry(x:Double(20), y:Double(136)))
        
        // se define una línea con los valores dentro del arreglo 'puntos'
        let set = LineChartDataSet(entries: puntos, label:"Presión Sistólica (mmHg)")
        set.colors = [NSUIColor.systemBlue]             // establece el color de la línea
        set.circleColors = [NSUIColor.systemBlue]       // establece el color del borde de los puntos
        set.mode = .cubicBezier
        set.lineWidth = 2
        set.drawHorizontalHighlightIndicatorEnabled = false
        set.highlightLineWidth = 1.5
        set.highlightColor = .systemBlue
        
        // crea un objeto LineChartData
        let chartData = LineChartData(dataSet: set)
        chartData.setDrawValues(false)      // quita los valores numéricos de los puntos
        
        // se le agregan los datos a la tabla
        chartView.data = chartData
        
        // ACOMODO DE GRÁFICA
        chartView.setVisibleXRangeMaximum(7.0)          // establece que se muestren solo 7 datos a la vez
        chartView.setVisibleYRange(
            minYRange: 100.0,
            maxYRange: 50.0,
            axis: .left)                                // establece los rangos min y max visibles del eje Y
        chartView.zoomToCenter(scaleX: 1, scaleY: 2)    // establece el zoom del eje Y en relación a al rango visible
        chartView.moveViewTo(
            xValue: Double(puntos.count-7),             // posiciona la vista en los 7 datos más recientes
            yValue: Double(130),                        // posiciona el centro del eje Y en 130
            axis: .left)
    }
    
    func cargarChartDiastolica() {
        
    }
    
    func cargarChartPulso() {
        
    }
    
//    MARK: - Queries a FireBase
    
    func cargarRegistros() {
        db.collection("registros").getDocuments { querySnap, err in
            if err != nil {
                let errorRegistros = "Error cargando los datos, intente más tarde."
                self.mostrarError(errorRegistros)
            }
            else{
                for documento in querySnap!.documents {
                    let data = documento.data()
                    let idRegistro = (data["idRegistro"] as? String) ?? ""
                    let idPaciente = (data["idPaciente"] as? String) ?? ""
                    let fecha = (data["fecha"] as? String) ?? ""
                    let hora = (data["hora"] as? String) ?? ""
                    let promSistolica = (data["promSistolica"] as? Double) ?? 0
                    let promDiastolica = (data["promDiastolica"] as? Double) ?? 0
                    let promPulso = (data["promPulso"] as? Double) ?? 0
                    let cantidadTomas = (data["cantidadTomas"] as? Int) ?? 0
                    
                    let unRegistro = Registro(
                        idRegistro: idRegistro, idPaciente: idPaciente,
                        fecha: fecha, hora: hora, promSistolica: promSistolica,
                        promDiastolica: promDiastolica, promPulso: promPulso,
                        cantidadTomas: cantidadTomas)
                    
                    self.registros.append(unRegistro)
                    
                    print("Registro: \(unRegistro)")
                    print("idRegistro: \(unRegistro.idRegistro ?? "")")
                    print("idPaciente: \(unRegistro.idPaciente ?? "")")
                    print("fecha: \(unRegistro.fecha ?? "")")
                    print("hora: \(unRegistro.hora ?? "")")
                    print("promSistolica: \(unRegistro.promSistolica ?? 0)")
                    print("promDiastolica: \(unRegistro.promDiastolica ?? 0)")
                    print("promPulso: \(unRegistro.promPulso ?? 0)")
                    print("cantidadTomas: \(unRegistro.cantidadTomas ?? 0)")
                }
            }
        }
    }
    
    func getRegistros() {
        // QUERY DE FIREBASE
        // obtiene todos los registros del paciente ordenados por la fecha
        db.collection("registros")
//            .whereField("idPaciente", isEqualTo: idPaciente!)
//            .order(by: "idRegistro")
            .getDocuments() { (querySnapshot, err) in
                print()
                if err != nil {
                    // en caso de error
                    let errorGetReg = "Error cargando los datos, intente más tarde."
                    self.mostrarError(errorGetReg)
//                    completion(errorGetReg)
                } else {
                    print("LETRERO")
                    // no hubo error, checa si hay registros
//                    guard let _ = querySnapshot else {
//                        let errorGetReg = "No hay registros de presión."
//                        self.mostrarError(errorGetReg)
//                        completion(errorGetReg)
//                        return
//                    }
                    
                    for document in querySnapshot!.documents {
                        // se almacenan los datos del documento
                        let data = document.data()
                        let idRegistro = (data["idRegistro"] as? String) ?? ""
                        let idPaciente = (data["idPaciente"] as? String) ?? ""
                        let fecha = (data["fecha"] as? String) ?? ""
                        let hora = (data["hora"] as? String) ?? ""
                        let promSistolica = (data["promSistolica"] as? Double) ?? 0
                        let promDiastolica = (data["promDiastolica"] as? Double) ?? 0
                        let promPulso = (data["promPulso"] as? Double) ?? 0
                        let cantidadTomas = (data["cantidadTomas"] as? Int) ?? 0
                        // se instancia un objeto Registro con los datos
                        let unRegistro = Registro(
                            idRegistro: idRegistro, idPaciente: idPaciente,
                            fecha: fecha, hora: hora, promSistolica: promSistolica,
                            promDiastolica: promDiastolica, promPulso: promPulso,
                            cantidadTomas: cantidadTomas)
                        // se almacena el registro en el arreglo
                        self.registros.append(unRegistro)
                        
                        print("Registro: \(unRegistro)")
                        print("idRegistro: \(unRegistro.idRegistro ?? "")")
                        print("idPaciente: \(unRegistro.idPaciente ?? "")")
                        print("fecha: \(unRegistro.fecha ?? "")")
                        print("hora: \(unRegistro.hora ?? "")")
                        print("promSistolica: \(unRegistro.promSistolica ?? 0)")
                        print("promDiastolica: \(unRegistro.promDiastolica ?? 0)")
                        print("promPulso: \(unRegistro.promPulso ?? 0)")
                        print("cantidadTomas: \(unRegistro.cantidadTomas ?? 0)")
                    }
//                    completion("¡Descarga registros exitosa!")
                }
            }
    }
    
    func getData() {
        db.collection("registros")
            .whereField("idPaciente", isEqualTo: idPaciente!)
            .order(by: "idRegistro")
            .getDocuments { querySnapshot, err in
            // verifica si hay errores
            if err != nil {
                // hubo error
                self.mostrarError("Error cargando los datos (getData)")
            } else {
                // no hubo error
                // verifica que haya registros
                if let querySnapshot = querySnapshot {
                    
                    // descarga todos los documentos y crea objetos Registro
                    self.registros = querySnapshot.documents.map { doc in
                        // transforma cada documento en Registros
                        
                        return Registro(idRegistro: doc.documentID,
                                        idPaciente: doc["idPaciente"] as? String ?? "",
                                        fecha: doc["fecha"] as? String ?? "",
                                        hora: doc["hora"] as? String ?? "",
                                        promSistolica: doc["promSistolica"] as? Double ?? 0,
                                        promDiastolica: doc["promDiastolica"] as? Double ?? 0,
                                        promPulso: doc["promPulso"] as? Double ?? 0,
                                        cantidadTomas: doc["cantidadTomas"] as? Int ?? 0)
                    }
                }
            }
        }
    }
    
        
//    MARK: - Funciones auxiliares
    func mostrarError(_ mensaje: String) {
        lbMensaje.text = mensaje
        lbMensaje.alpha = 1
        // oculta el mensaje después de 5 segundos
        perform(#selector(ocultarError), with: nil, afterDelay: 5)
    }
    
    @objc func ocultarError() {
        lbMensaje.alpha = 0
        lbMensaje.text = "Error"
    }

    
}
