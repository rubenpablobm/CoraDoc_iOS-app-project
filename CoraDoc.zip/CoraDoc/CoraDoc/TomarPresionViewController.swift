//
//  TomarPresionViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 17/09/22.
//

import UIKit
import Firebase

class TomarPresionViewController: UIViewController {
    
    @IBOutlet weak var tfSuperior: UITextField!
    @IBOutlet weak var tfInferior: UITextField!
    @IBOutlet weak var tfPulso: UITextField!
    @IBOutlet weak var lbError: UILabel!
    
    var idPaciente = Auth.auth().currentUser?.uid
    var fechaRegistro: String!
    var horaRegistro: String!
    var cantidadTomas = 0
    var tomas = [[Double]]()   // arreglo de arreglos de datos Double
    
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Tomar Presión"
        setupElements()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if cantidadTomas == 0 {
            // Si no ha hecho ninguna toma no hace nada
        } else {
            // Si ya se creo un registro:
            // Hace referencia al registro actual
            let idRegistro = fechaRegistro + "-" + horaRegistro + "-" + (idPaciente ?? "x")
            let registro = db.collection("registros").document(idRegistro)
            
            // calcula promedio
            let promSistolica = calculaPromedioSistolica(tomas)
            let promDiastolica = calculaPromedioDiastolica(tomas)
            let promPulso = calculaPromedioPulso(tomas)
            
            // se registra la cantidad de tomas y los promedios
            registro.setData(["cantidadTomas": cantidadTomas,
                              "promSistolica": promSistolica,
                              "promDiastolica": promDiastolica,
                              "promPulso": promPulso
                             ], merge: true)
        }
    }
    
    //    MARK: - Funciones de botones
    
    @IBAction func registrarToma(_ sender: UIButton) {
        let error = validarCampos()

        if error != nil {
            mostrarError(error!)
        }
        else {
            lbError.alpha = 0
            
            if cantidadTomas == 0 {
                // si es la primer toma se crea el documento del registro
                cantidadTomas += 1
                let presSuperior = Double(tfSuperior.text!)
                let presInferior = Double(tfInferior.text!)
                let pulso = Double(tfPulso.text!)
                fechaRegistro = formatoFecha(Date())
                horaRegistro = formatoHora(Date())
                let idRegistro = fechaRegistro + "-" + horaRegistro + "-" + (idPaciente ?? "x")
                let idToma = "toma" + String(cantidadTomas)
                
                let registro = db.collection("registros").document(idRegistro)
                
                registro.setData(["idRegistro":idRegistro, "idPaciente":idPaciente ?? "x",
                                  "fecha":fechaRegistro!, "hora":horaRegistro!,
                                  idToma: [presSuperior!, presInferior!, pulso!, horaRegistro!]
                                 ])
                
                // agrega los datos al arreglo de tomas
                tomas.append([presSuperior!, presInferior!, pulso!])
                
                tomaExitosa()
            } else {
                // si no es la primera toma, solo se agrega un nuevo arreglo
                cantidadTomas += 1
                let presSuperior = Double(tfSuperior.text!)
                let presInferior = Double(tfInferior.text!)
                let pulso = Double(tfPulso.text!)
                let hora = formatoHora(Date())
                let idRegistro = fechaRegistro + "-" + horaRegistro + "-" + (idPaciente ?? "x")
                let idToma = "toma" + String(cantidadTomas)
                
                let registro = db.collection("registros").document(idRegistro)
                
                registro.setData([idToma: [presSuperior!, presInferior!, pulso!, hora]
                                 ], merge: true)
                
                // agrega los datos al arreglo de tomas
                tomas.append([presSuperior!, presInferior!, pulso!])
                
                tomaExitosa()
            }
            view.endEditing(true)
        }
    }
    
    @IBAction func btnterminarRegistro(_ sender: UIButton) {
        lbError.alpha = 0
        // verifica s
        if cantidadTomas == 0 {
            // si es la primer toma se crea el documento del registro
            cantidadTomas += 1
            let presSuperior = Double(tfSuperior.text!)
            let presInferior = Double(tfInferior.text!)
            let pulso = Double(tfPulso.text!)
            fechaRegistro = formatoFecha(Date())
            horaRegistro = formatoHora(Date())
            let idRegistro = fechaRegistro + "-" + horaRegistro + "-" + (idPaciente ?? "x")
            let idToma = "toma" + String(cantidadTomas)
            
            let registro = db.collection("registros").document(idRegistro)
            
            registro.setData(["idRegistro":idRegistro, "idPaciente":idPaciente ?? "x",
                              "fecha":fechaRegistro!, "hora":horaRegistro!,
                              idToma: [presSuperior!, presInferior!, pulso!, horaRegistro!]
                             ])
            
            // agrega los datos al arreglo de tomas
            tomas.append([presSuperior!, presInferior!, pulso!])
            
            tomaExitosa()
        } else {
            // si no es la primera toma, solo se agrega un nuevo arreglo
            cantidadTomas += 1
            let presSuperior = Double(tfSuperior.text!)
            let presInferior = Double(tfInferior.text!)
            let pulso = Double(tfPulso.text!)
            let hora = formatoHora(Date())
            let idRegistro = fechaRegistro + "-" + horaRegistro + "-" + (idPaciente ?? "x")
            let idToma = "toma" + String(cantidadTomas)
            
            let registro = db.collection("registros").document(idRegistro)
            
            registro.setData([idToma: [presSuperior!, presInferior!, pulso!, hora]
                             ], merge: true)
            
            // agrega los datos al arreglo de tomas
            tomas.append([presSuperior!, presInferior!, pulso!])
            
            tomaExitosa()
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
//    MARK: - Funciones de validación
    
    // Valida que no se deje ningún campo vacío
    func validarCampos() -> String? {
        // verifica que no haya campos vacíos
        if tfSuperior.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfInferior.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfPulso.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            return("No deje ningún campo vacío.")
        }
        let superior = Double(tfSuperior.text!),
            inferior = Double(tfInferior.text!),
            pulso = Double(tfPulso.text!)
        // verifica que los datos ingresados sean numéricos
        if superior == nil ||
            inferior == nil ||
            pulso == nil {
            return("Sólo ingresa valores numéricos.")
        }
        return nil
    }
    
    func mostrarError(_ mensaje: String) {
        lbError.text = mensaje
        lbError.alpha = 1
    }
    
    @objc func ocultarError() {
        lbError.alpha = 0
        lbError.text = "Error"
    }
    
//    MARK: - Funciones para calcular promedios
    func calculaPromedioSistolica (_ arreglo: [[Double]]) -> Double {
        var suma = 0.0
        var toma = 0
        while (toma < self.cantidadTomas) {
            suma += arreglo[toma][0]
            toma += 1
        }
        return suma / Double(self.cantidadTomas)
    }
    
    func calculaPromedioDiastolica (_ arreglo: [[Double]]) -> Double {
        var suma = 0.0
        var toma = 0
        while (toma < self.cantidadTomas) {
            suma += arreglo[toma][1]
            toma += 1
        }
        return suma / Double(self.cantidadTomas)
    }
    
    func calculaPromedioPulso (_ arreglo: [[Double]]) -> Double {
        var suma = 0.0
        var toma = 0
        while (toma < self.cantidadTomas) {
            suma += arreglo[toma][2]
            toma += 1
        }
        return suma / Double(self.cantidadTomas)
    }
    
//    MARK: - Funciones auxiliares
    
    func setupElements() {
        lbError.alpha = 0
    }
    
    func formatoFecha(_ fecha: Date) -> String {
        let formato = DateFormatter()
        formato.dateFormat = "dd-MM-yyyy"
        return formato.string(from: fecha)
    }
    
    func formatoHora(_ hora: Date) -> String {
        let formato = DateFormatter()
        // esto hace que la hora siempre se almacene con un formato de 24hrs
        // sin importar la configuración del dispositivo ni la región
        formato.setLocalizedDateFormatFromTemplate("HH:mm:ss a")
        formato.amSymbol = ""
        formato.pmSymbol = ""
        formato.locale = Locale(identifier: "es_MX")
        return formato.string(from: hora)
            .trimmingCharacters(in: .whitespacesAndNewlines)    // elimita espacios en blanco de la hora
    }
    
    func tomaExitosa() {
        // libera los campos para la siguiente toma
        tfSuperior.text = ""
        tfInferior.text = ""
        tfPulso.text = ""
        // despliega mensaje de éxito
        lbError.text = "Toma registrada exitosamente."
        lbError.textColor = .systemBlue
        lbError.alpha = 1
        // oculta el mensaje después de 5 segundos
        perform(#selector(ocultarError), with: nil, afterDelay: 5)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
