//
//  PerfilViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 17/09/22.
//

import UIKit
import Firebase

class PerfilViewController: UIViewController {
    
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellidos: UITextField!
    @IBOutlet weak var tfFecha: UITextField!
    @IBOutlet weak var tfSexo: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfNumero: UITextField!
    @IBOutlet weak var lbError: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbError.alpha = 0
        
        setupElements()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        setupElements()
    }
    
//    MARK: - Funciones de botones
    
    @IBAction func cerrarSesion(_ sender: UIButton) {
        let auth = Auth.auth()
        
        do {
            try auth.signOut()
            // Cierra sesión en la base de datos
            try! Auth.auth().signOut()
            // Envía a pantalla origien (root)
            self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
            
        } catch let errorLogout {
            lbError.text = errorLogout.localizedDescription
        }
    }
    
//    MARK: - Funciones Firebase
    
    func getDatosPaciente() {
        db.collection("pacientes")
            .document(String(Auth.auth().currentUser!.uid))
            .getDocument { [self] documentSnapshot, err in
            if err != nil {
                self.lbError.text = "Error cargando los datos, intente más tarde."
                self.lbError.alpha = 1
                return
            }
            else {
                let data = documentSnapshot?.data()
                
                // simplifica formato Timestamp y lo hace String
                let nacimiento: String?
                if let timestamp = data?["nacimiento"] as? Timestamp {
                    nacimiento = self.fechaAString(timestamp)
                }
                else {
                    nacimiento = ""
                }
                
                self.tfNombre.text = (data?["nombre"] as! String)
                self.tfApellidos.text = (data?["apellidos"] as! String)
                self.tfFecha.text = nacimiento
                self.tfSexo.text = (data?["sexo"] as! String)
                self.tfEmail.text = (data?["email"] as! String)
                self.tfNumero.text = (data?["numCelular"] as! String)
                
                // oculta mensaje "Cargando datos..." al terminar
                ocultarMensaje()
            }
        }
    }
    
//    MARK: - Funciones auxiliares
    
    func setupElements() {
        // despliega mensaje
        self.lbError.text = "Cargando datos..."
        self.lbError.textColor = .systemBlue
        self.lbError.alpha = 1
        
        getDatosPaciente()
    }
    
    @objc func ocultarMensaje() {
        lbError.alpha = 0
        lbError.text = "Error"
    }
    
    func fechaAString(_ timestamp: Timestamp) -> String {
        let date = timestamp.dateValue()
        
        let dateFormatter = DateFormatter()
        // simplifica el formato de la fecha
        dateFormatter.dateStyle = .medium
        // elimina la hora del formato
        dateFormatter.timeStyle = .none
        
        return "\(dateFormatter.string(from: date))"
    }
    

//     MARK: - Navigation
    
    
    /*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
