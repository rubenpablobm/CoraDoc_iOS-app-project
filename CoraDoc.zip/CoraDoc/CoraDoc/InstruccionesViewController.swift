//
//  InstruccionesViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 19/09/22.
//

import UIKit

class InstruccionesViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var imgInstrucciones: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
 
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imgInstrucciones
    }
}

