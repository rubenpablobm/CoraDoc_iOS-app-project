//
//  EditarDatosViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 03/10/22.
//

import UIKit
import Firebase

class EditarDatosViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellidos: UITextField!
    @IBOutlet weak var tfFecha: UITextField!
    @IBOutlet weak var tfSexo: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfNumero: UITextField!
    @IBOutlet weak var lbError: UILabel!
    
    var idPaciente = Auth.auth().currentUser?.uid
    
    let datePicker = UIDatePicker()
    var fechaNacDP: Date!               // almacena el valor del Date Picker
    var didPressFecha = false           // indica si se ha modificado la fecha
    var fechaNacActualTS: Timestamp!    // almacena el valor de la fecha de nacimiento en la bd
    let sexos = ["", "Masculino", "Femenino", "Otro"]
    let sexPickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpElements()
        mensajeCargando()
        
        // rueda de fecha
        createDatepicker()
        // selector de sexo
        createSexPickerView()
        // se almacena el valor de la fecha de nacimiento actual
    }
    
    @IBAction func confirmarCambios(_ sender: UIButton) {
        lbError.alpha = 0
        
        // validar campos
        let error = validarCampos()
        
        if error != nil {
            // Hubo un error
            mostrarError(error!)
        }
        else {
            
            // crea versiones limpias de los datos
            let nombre = tfNombre.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let apellidos = tfApellidos.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let sexo = tfSexo.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let email = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let numCelular = tfNumero.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            let db = Firestore.firestore()
            
            if didPressFecha != false {
                // Si se modificó la fecha se envía el valor del Date Picker
                db.collection("pacientes")
                    .document(idPaciente!)
                    .setData(["nombre":nombre, "apellidos":apellidos,
                              "nacimiento":self.fechaNacDP!, "sexo":sexo,
                              "email":email, "numCelular":numCelular,
                              "uid":idPaciente!
                             ]) { (error) in
                    if error != nil {
                        // mostrar mensaje de error
                        self.mostrarError("Error con el sistema, intente más tarde")
                    }
                }
                lbError.text = "Cambios guardados exitosamente."
                lbError.textColor = .systemBlue
                lbError.alpha = 1
                dismiss(animated: true)
            }
            else {
                // Si no se modificó la fecha se envía la misma timestamp
                db.collection("pacientes")
                    .document(idPaciente!)
                    .setData(["nombre":nombre, "apellidos":apellidos,
                              "nacimiento":self.fechaNacActualTS!, "sexo":sexo,
                              "email":email, "numCelular":numCelular,
                              "uid":idPaciente!
                             ]) { (error) in
                    if error != nil {
                        // mostrar mensaje de error
                        self.mostrarError("Error con el sistema, intente más tarde")
                    }
                }
                lbError.text = "Cambios guardados exitosamente."
                lbError.textColor = .systemBlue
                lbError.alpha = 1
                dismiss(animated: true)
            }
        }
    }
    
    @IBAction func cancelar(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    //    MARK: - Funciones de validación
        
        // Valida que los datos son correctos, en ese caso regresa nil. De lo contrario regresa el mensaje de error.
        func validarCampos() -> String? {
            
            // Verifica que todos los campos tengan datos
            if tfNombre.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                tfApellidos.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                tfFecha.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                tfSexo.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                tfNumero.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                
                return "No deje ningún campo vacío."
            }
            
            // Verifica que el formato del correo sea correcto
            let emailLimpio = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            if !correoEsValido(emailLimpio) {
                tfEmail.text = ""
                return "El correo electrónico no es válido."
            }
            
            return nil
        }
        
        // Valida que el correo sea válido
        func correoEsValido(_ email: String) -> Bool {
            let mailPrueba = NSPredicate(format: "SELF MATCHES %@",
                                         "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}")
            return mailPrueba.evaluate(with: email)
        }
        
        func mostrarError(_ mensaje: String) {
            lbError.text = mensaje
            lbError.textColor = .systemRed
            lbError.alpha = 1
        }
    
    //    MARK: - Funciones Firebase
        
        func getDatosPaciente() {
            // carga los datos del paciente y los despliega en los Text Fields
            db.collection("pacientes")
                .document(String(Auth.auth().currentUser!.uid))
                .getDocument { documentSnapshot, err in
                if err != nil {
                    // error obteniendo los datos del paciente
                    self.lbError.text = "Error cargando los datos, intente más tarde."
                    self.lbError.alpha = 1
                    return
                }
                else {
                    let data = documentSnapshot?.data()
                    
                    // simplifica formato Timestamp y lo hace String
                    let nacimiento: String?
                    if let timestamp = data?["nacimiento"] as? Timestamp {
                        self.fechaNacActualTS = timestamp
                        nacimiento = self.fechaAString(timestamp)
                    }
                    else {
                        nacimiento = ""
                    }
                    
                    self.tfNombre.text = (data?["nombre"] as! String)
                    self.tfApellidos.text = (data?["apellidos"] as! String)
                    self.tfFecha.text = nacimiento
                    self.tfSexo.text = (data?["sexo"] as! String)
                    self.tfEmail.text = (data?["email"] as! String)
                    self.tfNumero.text = (data?["numCelular"] as! String)
                    
                    // oculta mensaje "Cargando datos..." al terminar
                    self.ocultarMensaje()
                }
            }
        }
    
    //    MARK: - Funciones auxiliares
    
        func setUpElements() {
            getDatosPaciente()
            // esconde label de error
            lbError.alpha = 0
        }
    
        @objc func ocultarMensaje() {
            lbError.alpha = 0
            lbError.text = "Error"
        }
        
        func mensajeCargando() {
            // despliega mensaje
            lbError.text = "Cargando datos..."
            lbError.textColor = .systemBlue
            lbError.alpha = 1
        }
        
        func fechaAString(_ timestamp: Timestamp) -> String {
            let date = timestamp.dateValue()
            
            let dateFormatter = DateFormatter()
            // simplifica el formato de la fecha
            dateFormatter.dateStyle = .medium
            // elimina la hora del formato
            dateFormatter.timeStyle = .none
            
            return "\(dateFormatter.string(from: date))"
        }
    
        @IBAction func quitarTeclado(_ sender: UITapGestureRecognizer) {
            view.endEditing(true)
        }
    
    
    //    MARK: - Funciones para la rueda de fecha
        func createToolbar() -> UIToolbar {
            // toolbar
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            
            // done btn
            let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
            toolbar.setItems([doneBtn], animated: true)
            
            return toolbar
        }
        
        func createDatepicker() {
            // establece estilo de rueda
            datePicker.preferredDatePickerStyle = .wheels
            // hace que sólo muestre fecha (sin hora)
            datePicker.datePickerMode = .date
            
            tfFecha.inputView = datePicker
            tfFecha.inputAccessoryView = createToolbar()
        }
        
        // para que el botón "Done" funcione
        @objc func donePressed() {
            // indica que se modificó la fecha de nacimiento
            didPressFecha = true
            
            let dateFormatter = DateFormatter()
            // simplifica el formato de la fecha
            dateFormatter.dateStyle = .medium
            // elimina la hora del formato
            dateFormatter.timeStyle = .none
            
            self.tfFecha.text = dateFormatter.string(from: datePicker.date)
            self.view.endEditing(true)
            
            fechaNacDP = datePicker.date
        }
        
    //    MARK: - Funciones para selector de sexo
        func createSexPickerView() {
            tfSexo.inputView = sexPickerView
            sexPickerView.delegate = self
            sexPickerView.dataSource = self
        }
        
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            sexos.count
        }
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            sexos[row]
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            tfSexo.text = sexos[row]
            tfSexo.resignFirstResponder()
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
