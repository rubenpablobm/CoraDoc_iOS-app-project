//
//  Paciente.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 04/10/22.
//

import UIKit
import Firebase

let db = Firestore.firestore()

class Paciente: NSObject, Codable {
    
    var nombre: String
    var apellidos: String
    var nacimiento: Date
    var sexo: String
    var email: String
    var numCelular: String
    
}



