//
//  Registro.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 14/10/22.
//

import UIKit

struct Registro: Codable {
    var idRegistro: String!
    var idPaciente: String!
    var fecha: String!
    var hora: String!
    var promSistolica: Double!
    var promDiastolica: Double!
    var promPulso: Double!
    var cantidadTomas: Int!
    //var tomas = [[Double]]()
    
    init (idRegistro: String, idPaciente: String, fecha: String, hora: String,
          promSistolica: Double, promDiastolica: Double, promPulso: Double, cantidadTomas: Int) {
        self.idRegistro = idRegistro
        self.idPaciente = idPaciente
        self.fecha = fecha
        self.hora = hora
        self.promSistolica = promSistolica
        self.promDiastolica = promDiastolica
        self.promPulso = promPulso
        self.cantidadTomas = cantidadTomas
    }
}
