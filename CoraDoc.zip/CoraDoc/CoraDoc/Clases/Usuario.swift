//
//  Usuario.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 28/09/22.
//

import UIKit

class Usuario: NSObject, Codable {

    var id: String!
    var nombre: String!
    var apellidos: String!
    
}
