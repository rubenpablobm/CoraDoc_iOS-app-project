//
//  CrearCuentaViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 08/09/22.
//

import UIKit
import FirebaseAuth
import Firebase
import FirebaseFirestore

class CrearCuentaViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellidos: UITextField!
    @IBOutlet weak var tfFecha: UITextField!
    @IBOutlet weak var tfSexo: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfNumero: UITextField!
    @IBOutlet weak var tfContrasena: UITextField!
    @IBOutlet weak var tfConfContra: UITextField!
    @IBOutlet weak var lbError: UILabel!
    @IBOutlet weak var btnCrearCuenta: UIButton!

    
    let datePicker = UIDatePicker()
    var nacimiento: Date!
    let sexos = ["", "Masculino", "Femenino", "Otro"]
    let sexPickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpElements()
        
        // rueda de fecha
        createDatepicker()
        // selector de sexo
        createSexPickerView()
    }
    
    func setUpElements() {
        // esconde label de error
        lbError.alpha = 0
    }
    
    //    MARK: - Funciones de los botones
        @IBAction func btnCrearCuenta(_ sender: UIButton) {
            // validar campos
            let error = validarCampos()
            
            if error != nil {
                // Hubo un error
                mostrarError(error!)
            }
            else {
                
                // crea versiones limpias de los datos
                let nombre = tfNombre.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                let apellidos = tfApellidos.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                let sexo = tfSexo.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                let email = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                let numCelular = tfNumero.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                let contrasena = tfContrasena.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                
                // crear usuario
                Auth.auth().createUser(withEmail: email, password:  contrasena) { (result, err) in
                    
                    // checa si existen errores
                    if err != nil {
                        
                        // hubo un error creando el usuario
                        self.mostrarError("Error creando el usuario")
                    }
                    else {
                        // usuario creado exitosamente
                        let db = Firestore.firestore()
                        
                        let nuevoPaciente = db.collection("pacientes").document(result!.user.uid)
                        
                        nuevoPaciente.setData(["nombre":nombre, "apellidos":apellidos,
                                               "nacimiento":self.nacimiento!, "sexo":sexo,
                                               "email":email, "numCelular":numCelular,
                                               "uid":result!.user.uid
                                              ]) { (error) in
                           if error != nil {
                               // mostrar mensaje de error
                               self.mostrarError("Error con el sistema, intente más tarde")
                           }
                       }
                        
                        self.performSegue(withIdentifier: "crearCuentaSegue", sender: Any?.self)
                    }
                }
            }
        }
        
        @IBAction func btnCancelar(_ sender: UIButton) {
            dismiss(animated: true)
        }
        
        // Para quitar el teclado con tocar la pantalla:
        @IBAction func quitaTeclado(_ sender: UITapGestureRecognizer) {
            view.endEditing(true)
        }
    
//    MARK: - Funciones de validación
    
    // Valida que los datos son correctos, en ese caso regresa nil. De lo contrario regresa el mensaje de error.
    func validarCampos() -> String? {
        
        // Verifica que todos los campos tengan datos
        if tfNombre.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfApellidos.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfFecha.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfSexo.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfNumero.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfContrasena.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            tfConfContra.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "No deje ningún campo vacío."
        }
        
        // Verifica que el formato del correo sea correcto
        let emailLimpio = tfEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if !correoEsValido(emailLimpio) {
            tfEmail.text = ""
            return "El correo electrónico no es válido."
        }
        
        // Verifica que la contraseña y su confirmación sean iguales
        if tfContrasena.text != tfConfContra.text {
            tfConfContra.text = ""
            return "Las contraseñas no coinciden."
        }
        
        // Verifica que la contraseña sea segura
        let contrasenaLimpia = tfContrasena.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if !contrasenaEsSegura(contrasenaLimpia) {
            tfContrasena.text = ""
            tfConfContra.text = ""
            return "La contraseña debe medir mínimo 8 caracteres y tener al menos 1 mayúscula y 1 número"
        }
        
        return nil
    }
    
    // Valida que el correo sea válido
    func correoEsValido(_ email: String) -> Bool {
        let mailPrueba = NSPredicate(format: "SELF MATCHES %@",
                                     "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}")
        return mailPrueba.evaluate(with: email)
    }
    
    // Valida que la contraseña sea segura
    func contrasenaEsSegura(_ contrasena: String) -> Bool {
        let contraPrueba = NSPredicate(format: "SELF MATCHES %@",
            "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[A-Za-z\\d$@$#!%*?&]{8,}")
        // al menos una mayuscula y un número, al menos 8 caracteres
        return contraPrueba.evaluate(with: contrasena)
    }
    
    func mostrarError(_ mensaje: String) {
        lbError.text = mensaje
        lbError.alpha = 1
    }

//    MARK: - Funciones para la rueda de fecha
    func createToolbar() -> UIToolbar {
        // toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        // done btn
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated: true)
        
        return toolbar
    }
    
    func createDatepicker() {
        // establece estilo de rueda
        datePicker.preferredDatePickerStyle = .wheels
        // hace que sólo muestre fecha (sin hora)
        datePicker.datePickerMode = .date
        
        tfFecha.inputView = datePicker
        tfFecha.inputAccessoryView = createToolbar()
    }
    
    // para que el botón "Done" funcione
    @objc func donePressed() {
        let dateFormatter = DateFormatter()
        // simplifica el formato de la fecha
        dateFormatter.dateStyle = .medium
        // elimina la hora del formato
        dateFormatter.timeStyle = .none
        
        self.tfFecha.text = dateFormatter.string(from: datePicker.date)
        self.view.endEditing(true)
        
        // se asigna el valor de fecha a la variable nacimiento
        nacimiento = datePicker.date
    }
    
//    MARK: - Funciones para selector de sexo
    func createSexPickerView() {
        tfSexo.inputView = sexPickerView
        sexPickerView.delegate = self
        sexPickerView.dataSource = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        sexos.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        sexos[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        tfSexo.text = sexos[row]
        tfSexo.resignFirstResponder()
    }
    
    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
