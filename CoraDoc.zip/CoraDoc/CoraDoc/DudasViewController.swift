//
//  DudasViewController.swift
//  CoraDoc
//
//  Created by Ruben Pablo on 17/09/22.
//

import UIKit

class DudasViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Créditos"
    }
    
    
}
